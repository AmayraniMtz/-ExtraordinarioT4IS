package com.example.pregunta3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pregunta3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
