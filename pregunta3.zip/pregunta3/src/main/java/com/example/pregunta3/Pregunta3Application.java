package com.example.pregunta3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pregunta3Application {

	public static void main(String[] args) {
		SpringApplication.run(Pregunta3Application.class, args);
	}

}
